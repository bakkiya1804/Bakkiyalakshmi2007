// Dynamic year in footer
document.getElementById("year").textContent = new Date().getFullYear();

// Contact form handler
document.getElementById("contactForm").addEventListener("submit", function (e) {
  e.preventDefault();

  let name = document.getElementById("name").value.trim();
  let email = document.getElementById("email").value.trim();
  let message = document.getElementById("message").value.trim();
  let msgBox = document.getElementById("formMsg");

  if (!name || !email || !message) {
    msgBox.style.color = "red";
    msgBox.textContent = "⚠ Please fill in all fields.";
    return;
  }

  msgBox.style.color = "green";
  msgBox.textContent = "✅ Message sent successfully!";
  this.reset();
});